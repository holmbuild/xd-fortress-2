@echo off
rem XD Fortress 2 installer: double-click it. It finds Steam, installs Git if it is missing and
rem downloads the mod into Steam's sourcemods folder. Updates are done with Uppdatera.cmd in the mod.
setlocal
title Install XD Fortress 2
echo.
echo  XD Fortress 2 installer
echo  -----------------------
echo.

rem Where Steam itself is installed (not the other game libraries)
set "STEAM="
for /f "tokens=2,*" %%a in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul ^| find "SteamPath"') do set "STEAM=%%b"
if not defined STEAM (
    echo  Steam was not found. Install Steam, log in, and run this file again.
    goto fail
)
set "STEAM=%STEAM:/=\%"
set "DEST=%STEAM%\steamapps\sourcemods\mod_tf"
if defined XD_TEST_DEST set "DEST=%XD_TEST_DEST%"

rem Git: use the installed one, or install it with winget
set "GIT=git"
where git >nul 2>nul && goto havegit
if exist "%ProgramFiles%\Git\cmd\git.exe" set "GIT=%ProgramFiles%\Git\cmd\git.exe" & goto havegit
echo  Installing Git (the mod uses it to download and update). If Windows asks, click Yes.
echo.
winget install --id Git.Git -e --source winget --silent --accept-package-agreements --accept-source-agreements
if exist "%ProgramFiles%\Git\cmd\git.exe" set "GIT=%ProgramFiles%\Git\cmd\git.exe" & goto havegit
echo.
echo  Git could not be installed by itself. Install it from https://git-scm.com/download/win
echo  ^(click Next on every screen^), then run this file again.
goto fail

:havegit
if exist "%DEST%\.git" (
    echo  XD Fortress 2 is already installed. Updating it instead...
    echo.
    cd /d "%DEST%"
    "%GIT%" checkout -- maps/graphs >nul 2>nul
    "%GIT%" pull --ff-only || goto fail
    goto shortcut
)
if exist "%DEST%" (
    rem An old copy (for example from the zip): keep it next to the new one
    set "OLD=%DEST%_old_%RANDOM%"
    call echo  Moving your old mod_tf folder to %%OLD%%
    call move "%DEST%" "%%OLD%%" >nul || (
        echo  Could not move the old folder. Close the game and run this file again.
        goto fail
    )
)
for %%d in ("%DEST%\..") do if not exist "%%~fd" mkdir "%%~fd"
echo  Downloading the mod to:
echo    %DEST%
echo  It is about 1 GB, so this takes a few minutes. Please wait...
echo.
"%GIT%" -c core.longpaths=true clone --depth 1 https://github.com/holmbuild/xd-fortress-2.git "%DEST%" || goto fail
"%GIT%" -C "%DEST%" config core.longpaths true

:shortcut
rem A button on the desktop that runs the mod's own Uppdatera.cmd
set "DESK="
for /f "delims=" %%d in ('powershell -NoProfile -Command "[Environment]::GetFolderPath('Desktop')"') do set "DESK=%%d"
if defined XD_TEST_DEST for %%d in ("%DEST%\..") do set "DESK=%%~fd"
if defined DESK (
    > "%DESK%\Update XD Fortress 2.cmd" echo @call "%DEST%\Uppdatera.cmd"
    echo  Put "Update XD Fortress 2" on your desktop. Double-click it when the game says there is an update.
)

:done
echo.
echo  =========================================================
echo   DONE! Now restart Steam: click Steam at the top left,
echo   then Exit. Start Steam again and play XD Fortress 2.
echo  =========================================================
echo.
pause
exit /b 0

:fail
echo.
echo  The install did not finish. Check your internet connection and try again.
echo.
pause
exit /b 1
